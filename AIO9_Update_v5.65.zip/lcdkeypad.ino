#include "globals.h"

/*
 * LCD - I2C based SCL,SDA,VCC,GND
 * KEYPAD
 */
#define ROW_NUM 2    // four rows
#define COLUMN_NUM 3 // four columns
char keys[ROW_NUM][COLUMN_NUM] = {{'1', '2', '3'}, {'4', '5', '6'}};
char *key_name[7] = {"NOKEY", "CLEAR", "UP", "SET", "LEFT", "DOWN", "RIGHT"};
byte pin_rows[ROW_NUM] = {4, 12};           // R1,R2
byte pin_column[COLUMN_NUM] = {13, 14, 15}; // C1,C2,C3
Keypad keypad =
    Keypad(makeKeymap(keys), pin_rows, pin_column, ROW_NUM, COLUMN_NUM);
int calib_initial = 0;

// Keypad timing configuration for better responsiveness
void configure_keypad() {
  keypad.setDebounceTime(50); // 50ms debounce - prevents false triggers
  keypad.setHoldTime(500);    // 500ms hold time
}

/*
 * UI related
 */
extern int cur_fld_no, cur_mode;
int cur_char_no, cur_pos_no, disp_fld_no, cursor_type;

char inpCharSet[2][49] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ",
                          "0123456789./-,: "};
char key, input_buf[17];

// Returns true if the field should be shown for the current SYSTEM
bool isFieldVisible(int fld_id) {
#if ENABLE_WEBSERVER == 0
  if (fld_id == FLD_WIFI_ENABLE)
    return false;
#endif

#if ENABLE_PRESSURE_SENSOR == 1
  if (fld_id == FLD_PRESSURE || fld_id == FLD_ALTITUDE) {
    if (SYSTEM == 1 && strstr(UNIT, "KSNDMC_TWS-AP"))
      return true;
    return false;
  }
#else
  if (fld_id == FLD_PRESSURE || fld_id == FLD_ALTITUDE)
    return false;
#endif

#if SYSTEM == 0 // TRG ONLY
  if (fld_id == FLD_WIND_DIR || fld_id == FLD_INST_WS || fld_id == FLD_AVG_WS ||
      fld_id == FLD_TEMP || fld_id == FLD_HUMIDITY || fld_id == FLD_PRESSURE ||
      fld_id == FLD_ALTITUDE)
    return false;
#elif SYSTEM == 1 // TWS ONLY (Weather)
  if (fld_id == FLD_RF_ML || fld_id == FLD_RF_CALIB || fld_id == FLD_RF_RES)
    return false;
  // #1: Hide altitude field if BME280 is not installed
  if (fld_id == FLD_ALTITUDE && bmeType == BME_UNKNOWN)
    return false;
#elif SYSTEM == 2 // TWS-RF
  // #1: Hide altitude field if BME280 is not installed
  if (fld_id == FLD_ALTITUDE && bmeType == BME_UNKNOWN)
    return false;
#endif
  return true;
}

// Define timer variables
hw_timer_t *calib_timer = NULL;
hw_timer_t *lcd_timer = NULL;

volatile bool timerFlag = false;
unsigned long calib_start_time = 0;

// CALIB Timer ISR callback function
void IRAM_ATTR onTimer() {
  portENTER_CRITICAL_ISR(&timerMux1);
  timerFlag = true; // Set the flag when the timer interrupts
  portEXIT_CRITICAL_ISR(&timerMux1);
}

// LCD Timer ISR callback function
void IRAM_ATTR lcdTimer() {
  portENTER_CRITICAL_ISR(&timerMux2);
  lcdkeypad_start = 0; // Set the flag when the timer interrupts
  // protectI2CPins() cannot be called from ISR safely, but GPIO write is fast
  digitalWrite(32, LOW); // Turn OFF power to LCD (5V)
  portEXIT_CRITICAL_ISR(&timerMux2);
}

// v5.49: Pin protection helpers for electrical stability
void protectI2CPins() {
  pinMode(21, INPUT); // High impedance - prevent back-feeding
  pinMode(22, INPUT);
}

void unprotectI2CPins() {
  pinMode(21, INPUT_PULLUP);
  pinMode(22, INPUT_PULLUP);
}

// v5.60: Central drawing function - differential to eliminate flicker
void draw_current_page() {
  if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(I2C_MUTEX_WAIT_TIME)) == pdTRUE) {
    if (cur_mode == eEditOff) {
      lcd.noBlink();
      char line0[17], line1[17];
      memset(line0, ' ', 16); line0[16] = '\0';
      memset(line1, ' ', 16); line1[16] = '\0';

      // Special handling for legacy fields with dynamic logic
      if (cur_fld_no == FLD_WIFI_ENABLE) {
        strcpy(line0, wifi_active ? "DISABLE WIFI    " : "ENABLE WIFI     ");
        strcpy(line1, wifi_active ? "ACTIVE          " : "PRESS SET       ");
      } else if (cur_fld_no == FLD_LCD_OFF) {
        strcpy(line0, "TURN OFF LCD    ");
        strcpy(line1, "PRESS SET       ");
      } else {
        snprintf(line0, 17, "%-16s", ui_data[cur_fld_no].topRow);
        snprintf(line1, 17, "%-16s", ui_data[cur_fld_no].bottomRow);

        // Blink "PLEASE WAIT.." for manual status queue
        bool is_pending = (pending_manual_status && cur_fld_no == FLD_SEND_STATUS) ||
                          (pending_manual_gps && cur_fld_no == FLD_SEND_GPS);
        if (is_pending && (millis() / 500) % 2 == 0) {
          memset(line1, ' ', 16);
          line1[16] = '\0';
        }
      }

      // --- LCD Heartbeat (Restore Original Bonus) ---
      static bool heartState = false;
      static unsigned long lastHeartbeat = 0;
      if (millis() - lastHeartbeat > 1000) {
        lastHeartbeat = millis();
        heartState = !heartState;
        line0[15] = heartState ? '.' : ' '; 
      }

      // Differential Drawing: Only write if something changed
      if (strcmp(line0, present_topRow) != 0) {
        lcd.setCursor(0, 0);
        lcd.print(line0);
        strcpy(present_topRow, line0);
      }
      if (strcmp(line1, present_bottomRow) != 0) {
        lcd.setCursor(0, 1);
        lcd.print(line1);
        strcpy(present_bottomRow, line1);
      }

    } else if (cur_mode == eEditOn) {
      char line0[17], line1[17];
      lcd.setCursor(0, 0);
      snprintf(line0, sizeof(line0), "%-16s", ui_data[cur_fld_no].topRow);
      lcd.print(line0);
      lcd.setCursor(0, 1);
      snprintf(line1, sizeof(line1), "%-16s", input_buf);
      lcd.print(line1);
      lcd.setCursor(cur_pos_no, 1);
      lcd.blink();
      // Invalidate cache for transition back to EditOff
      present_topRow[0] = 0; present_bottomRow[0] = 0;
    }
    xSemaphoreGive(i2cMutex);
  }
}

// v5.60: Background data refresh - exact original formatting
void refresh_sensor_data() {
  // Update static fields
  strcpy(ui_data[FLD_STATION].topRow, "STATION ID");
  snprintf(ui_data[FLD_STATION].bottomRow, 17, "%-16s", station_name);
  snprintf(ui_data[FLD_VERSION].bottomRow, 17, "%-16s", UNIT_VER);
  snprintf(ui_data[FLD_DATE].bottomRow, 17, "%02d-%02d-%04d", current_day, current_month, current_year);
  snprintf(ui_data[FLD_TIME].bottomRow, 17, "%02d:%02d", current_hour, current_min);
  if (strlen(last_logged) == 0) {
    snprintf(ui_data[FLD_LAST_LOGGED].bottomRow, 17, "%-16s", "NA");
  } else {
    snprintf(ui_data[FLD_LAST_LOGGED].bottomRow, 17, "%-16s", last_logged);
  }

  // Battery & Solar
  static unsigned long last_bat = 0;
  if (millis() - last_bat > 5000) {
    last_bat = millis();
    li_bat = adc1_get_raw(ADC1_CHANNEL_5);
    li_bat_val = li_bat * 0.0010915;
    snprintf(ui_data[FLD_BATTERY].bottomRow, 17, "%04.1f", li_bat_val);
    bat_val = li_bat_val;

    if (!wifi_active) {
       int solar_raw;
       if (adc2_get_raw(ADC2_CHANNEL_8, ADC_WIDTH_BIT_12, &solar_raw) == ESP_OK) {
         solar_val = (solar_raw / 4096.0) * 3.6 * 7.2;
         snprintf(ui_data[FLD_SOLAR].bottomRow, 17, "%04.1f", solar_val);
       }
    }
  }

  // Live fields
  if (cur_fld_no == FLD_TEMP) snprintf(ui_data[FLD_TEMP].bottomRow, 17, "%0.1f", temperature);
  else if (cur_fld_no == FLD_HUMIDITY) snprintf(ui_data[FLD_HUMIDITY].bottomRow, 17, "%0.1f", humidity);
  else if (cur_fld_no == FLD_INST_WS) snprintf(ui_data[FLD_INST_WS].bottomRow, 17, "%0.2f", cur_wind_speed);
  else if (cur_fld_no == FLD_AVG_WS) snprintf(ui_data[FLD_AVG_WS].bottomRow, 17, "%0.2f", cur_avg_wind_speed);
  else if (cur_fld_no == FLD_WIND_DIR) snprintf(ui_data[FLD_WIND_DIR].bottomRow, 17, "%03d", (int)windDir);
  else if (cur_fld_no == FLD_PRESSURE) snprintf(ui_data[FLD_PRESSURE].bottomRow, 17, "%0.1f", pressure);
  else if (cur_fld_no == FLD_RF_ML) {
    float live_rf = (float)rf_count.val * RF_RESOLUTION;
    snprintf(ui_data[FLD_RF_ML].bottomRow, 17, "%06.2f", live_rf);
  }
  else if (cur_fld_no == FLD_SIM_STATUS) {
    int rssi = signal_strength;
    bool sigValid = !(rssi == 0 || rssi == 99 || rssi == -114);
    if (strlen(carrier) == 0 || strcmp(carrier, "NA") == 0 || !sigValid) {
      strcpy(ui_data[FLD_SIM_STATUS].topRow, "SIGNAL          ");
      strcpy(ui_data[FLD_SIM_STATUS].bottomRow, "FETCHING...     ");
    } else {
      snprintf(ui_data[FLD_SIM_STATUS].topRow, 17, "SIM:%s", carrier);
      if (rssi > 0) strcpy(ui_data[FLD_SIM_STATUS].bottomRow, "SIGNAL: WEAK    ");
      else snprintf(ui_data[FLD_SIM_STATUS].bottomRow, 17, "%d dBm         ", rssi);
    }
  }
  else if (cur_fld_no == FLD_REGISTRATION) {
    if (strcmp(reg_status, "NA") == 0) strcpy(ui_data[FLD_REGISTRATION].bottomRow, "FETCHING...     ");
    else snprintf(ui_data[FLD_REGISTRATION].bottomRow, 17, "%-16s", reg_status);
  }
  else if (cur_fld_no == FLD_HTTP_FAILS && pcb_clear_state == 0) {
    static unsigned long last_bl = 0;
    static int bl_cur = 0;
    if (millis() - last_bl > 2000) {
      last_bl = millis();
      bl_cur = get_total_backlogs();
    }
    snprintf(ui_data[FLD_HTTP_FAILS].bottomRow, 17, "P:%-2d C:%-4d B:%-4d", 
             diag_http_present_fails, diag_http_cum_fails, bl_cur);
  }
  else if (cur_fld_no == FLD_RF_RES && rf_res_edit_state == 0) {
    snprintf(ui_data[FLD_RF_RES].bottomRow, 17, "%.2f", RF_RESOLUTION);
  }
  else if (cur_fld_no == FLD_LOG) {
    if (last_recorded_yy > 0) {
      snprintf(ui_data[FLD_LOG].bottomRow, 17, "%04d%02d%02d %02d:%02d", 
               last_recorded_yy, last_recorded_mm, last_recorded_dd, 
               last_recorded_hr, last_recorded_min);
    } else {
      int p_min = (current_min / 15) * 15;
      snprintf(ui_data[FLD_LOG].bottomRow, 17, "%04d%02d%02d %02d:%02d", 
               current_year, current_month, current_day, current_hour, p_min);
    }
  }
}

void lcdkeypad(void *pvParameters) {
  esp_task_wdt_add(NULL);
  static int calib_mode = 0; // 0=Field, 1=Test
  static int last_lcd_state = 0; 
  static char savedWakeupKey = NO_KEY;
  static int delete_confirm_state = 0; // v5.60: For two-step factory reset

  configure_keypad();

  lcdkeypad_start = 0;
  calib_flag = 0;
  delay(1000);
  disp_fld_no = -1;
  cur_fld_no = 0;
  input_buf[0] = 0;
  input_buf[16] = 0; 
  show_now = 1;

  if (wired == 0) {
    digitalWrite(32, LOW); 
  } else {
    if (wakeup_reason_is != timer) {
      digitalWrite(32, HIGH); 
      lcdkeypad_start = 1;
    } else {
      digitalWrite(32, LOW);
      lcdkeypad_start = 0;
    }
  }
  vTaskDelay(100 / portTICK_PERIOD_MS);

  // Load Calibration string for UI display
#if (SYSTEM == 0) || (SYSTEM == 2)
  if (SPIFFS.exists("/calib.txt")) {
    File f8 = SPIFFS.open("/calib.txt", FILE_READ);
    if (f8) {
      String c = f8.readStringUntil('\n');
      f8.close();
      strncpy(ui_data[FLD_RF_CALIB].bottomRow, c.c_str(), 16);
      ui_data[FLD_RF_CALIB].bottomRow[16] = '\0';
      strcpy(calib_text, c.c_str());

      // v5.61: Parse historical calibration data into RTC variables for SMS/Status reports
      int yr, mo, dy;
      char st[8];
      if (sscanf(calib_text, "%04d-%02d-%02d %s", &yr, &mo, &dy, st) >= 3) {
        calib_year = yr;
        calib_month = mo;
        calib_day = dy;
        if (strstr(st, "PASS"))
          calib_sts = 1;
        else
          calib_sts = 0;
        debugf("[CALIB] Loaded: %04d-%02d-%02d Status: %d\n", calib_year,
               calib_month, calib_day, calib_sts);
      }
    }
  }
#endif

  for (;;) {
    esp_task_wdt_reset();

    if (lcdkeypad_start == 1 && wifi_active) {
      timerWrite(lcd_timer, 0);
    }

    if (lcdkeypad_start == 0) {
      char wakeupKey = keypad.getKey();
      if (wakeupKey != NO_KEY || digitalRead(27) == LOW) {
        wakeup_reason_is = ext0;
        savedWakeupKey = wakeupKey;
        debugf("[UI] Wakeup detected. Key: %c\n", (wakeupKey != NO_KEY ? wakeupKey : 'P'));
        delay(200); 
      }
    }

    bool should_activate = (wakeup_reason_is == ext0) || (wired == 1 && wakeup_reason_is == 0 && lcd_timer == NULL);

    if (last_lcd_state == 1 && lcdkeypad_start == 0) {
      protectI2CPins();
    }
    last_lcd_state = lcdkeypad_start;

    if (should_activate) {
      if (lcdkeypad_start == 0 || lcd_timer == NULL) {
        unprotectI2CPins();
        digitalWrite(32, HIGH);
        vTaskDelay(1000 / portTICK_PERIOD_MS);
        cur_fld_no = 0; // v5.60: Ensure we always start at Station ID on wakeup

        if (lcd_timer == NULL) {
          lcd_timer = timerBegin(1000000);
          if (lcd_timer) timerAttachInterrupt(lcd_timer, &lcdTimer);
        }
        
        pinMode(4, INPUT_PULLUP);
        pinMode(12, INPUT_PULLUP);
        pinMode(13, OUTPUT);
        pinMode(14, OUTPUT);
        pinMode(15, OUTPUT);

        if (lcd_timer) {
          timerAlarm(lcd_timer, 180000000, false, 0); // v5.60: 180s default 
          timerWrite(lcd_timer, 0);
        }

        lcdkeypad_start = 1;
        // cur_fld_no = 0 already handled in wakeup block
        vTaskDelay(200 / portTICK_PERIOD_MS);

        if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(I2C_MUTEX_WAIT_TIME)) == pdTRUE) {
          lcd.init();
          lcd.display();
          lcd.backlight();
          lcd.clear();
          lcd.noCursor();
          lcd.noBlink();
          show_now = 1;
          xSemaphoreGive(i2cMutex);
        } else {
          lcdkeypad_start = 0;
        }
      } else {
        timerWrite(lcd_timer, 0);
        timerAlarm(lcd_timer, 180000000, false, 0); // v5.60: 180s
      }
      wakeup_reason_is = timer;
    }

    if (lcdkeypad_start == 1) {
      // Background Data Preparation
      if (calib_flag == 1) {
        // Calibration Running logic
        if (millis() - calib_start_time > 300000) { // 5 min timeout
          calib_flag = 2; // Auto stop
        }
        float live_c_rf = (float)calib_count.val * RF_RESOLUTION;
        if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
          if (!calib_header_drawn) {
            lcd.setCursor(0, 0);
            lcd.print("Count     RF(mm)");
            calib_header_drawn = 1;
          }
          lcd.setCursor(0, 1);
          char b[17];
          snprintf(b, 17, "%-5d     %-6.2f", (int)calib_count.val, live_c_rf);
          lcd.print(b);
          xSemaphoreGive(i2cMutex);
        }
      } else if (calib_flag == 2) {
        // Calibration Result logic
        calib_mode_flag.val = 0; 
        calib_flag = 0;
        int count = calib_count.val;
        bool pass = (count == 10);
        snprintf(calib_text, sizeof(calib_text), "%04d-%02d-%02d %s", 
                 current_year, current_month, current_day, (pass ? "PASS" : "FAIL"));
        
        // v5.61: Update global status variables immediately (Survive Sleep for SMS/Health)
        calib_sts = pass ? 1 : 0;
        calib_year = current_year;
        calib_month = current_month;
        calib_day = current_day;

        File f = SPIFFS.open("/calib.txt", FILE_WRITE);
        if (f) { f.print(calib_text); f.close(); }

        if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
          lcd.clear();
          lcd.setCursor(0, 0);
          lcd.print("FIELD CALIB:");
          lcd.setCursor(0, 1);
          lcd.print(calib_text);
          xSemaphoreGive(i2cMutex);
          
          // Persistence: Store in UI data so it stays after navigation
          strncpy(ui_data[FLD_RF_CALIB].bottomRow, calib_text, 16);
          ui_data[FLD_RF_CALIB].bottomRow[16] = '\0';
          
          vTaskDelay(3000 / portTICK_PERIOD_MS);
          show_now = 1;
        }
      } else {
        // Periodic Refresh
        static unsigned long refresh_timer = 0;
        if (show_now || (millis() - refresh_timer > 500)) {
          refresh_timer = millis();
          refresh_sensor_data();
          draw_current_page();
          show_now = 0;
        }
      }

      // --- KEYPAD PROCESSING ---
      key = keypad.getKey();
      if (key == NO_KEY && savedWakeupKey != NO_KEY) {
        key = savedWakeupKey;
        savedWakeupKey = NO_KEY;
      }

      if (key != NO_KEY) {
        extern unsigned long last_key_time;
        last_key_time = millis();
        if (lcd_timer) {
          timerWrite(lcd_timer, 0);
          timerAlarm(lcd_timer, 180000000, false, 0);
        }

        int i = (int)key - 48;
        if (i < 0 || i > 6) i = 0;

        int len = 0;
        if (ui_data[cur_fld_no].fieldType == eNumeric || ui_data[cur_fld_no].fieldType == eAlphaNum) {
          len = strlen(inpCharSet[ui_data[cur_fld_no].fieldType]);
        }

        switch (i) {
        case 1: // CLEAR
          if (cur_mode == eEditOn) {
            if (cur_fld_no == FLD_RF_RES) {
              rf_res_edit_state = 0;
              strcpy(ui_data[FLD_RF_RES].topRow, "RF RESOLUTION");
            } else if (cur_fld_no == FLD_DELETE_DATA) {
              strcpy(ui_data[FLD_DELETE_DATA].topRow, "DELETE DATA?");
            }
            cur_mode = eEditOff;
            show_now = 1;
          } else if (pcb_clear_state == 1) {
            pcb_clear_state = 0;
            show_now = 1;
          } else if (calib_flag == 1) {
            calib_flag = 0;
            calib_mode_flag.val = 0;
            show_now = 1;
          } else if (delete_confirm_state == 1) {
            delete_confirm_state = 0;
            strcpy(ui_data[FLD_DELETE_DATA].topRow, "DELETE DATA?");
            show_now = 1;
          } else if (rf_res_edit_state > 0) {
            rf_res_edit_state = 0;
            strcpy(ui_data[FLD_RF_RES].topRow, "RF RESOLUTION");
            cur_mode = eEditOff;
            show_now = 1;
          }
          break;

        case 2: // UP
          if (cur_mode == eEditOn) {
            cur_char_no = (cur_char_no + 1 + len) % len;
            if (cur_pos_no < 16) input_buf[cur_pos_no] = inpCharSet[ui_data[cur_fld_no].fieldType][cur_char_no];
          } else {
            int start_fld = cur_fld_no;
            do {
              cur_fld_no = (cur_fld_no + 1) % FLD_COUNT;
            } while (!isFieldVisible(cur_fld_no) && cur_fld_no != start_fld);

            if (cur_fld_no == FLD_LOG && last_recorded_yy > 0) {
               snprintf(ui_data[FLD_LOG].bottomRow, 17, "%04d%02d%02d %02d:%02d", 
                        last_recorded_yy, last_recorded_mm, last_recorded_dd, 
                        last_recorded_hr, last_recorded_min);
            }
          }
          show_now = 1;
          break;

        case 3: // SET
          if (cur_fld_no == FLD_LCD_OFF) {
            lcdkeypad_start = 0; digitalWrite(32, LOW);
          } else if (cur_fld_no == FLD_SEND_STATUS) {
            if (sync_mode == eSyncModeInitial || sync_mode == eSMSStop || sync_mode == eHttpStop || sync_mode == eExceptionHandled) {
              send_status = 1; sync_mode = eSMSStart;
              strcpy(ui_data[FLD_SEND_STATUS].bottomRow, "SENDING...     ");
            } else {
              pending_manual_status = true;
              strcpy(ui_data[FLD_SEND_STATUS].bottomRow, "PLEASE WAIT..  ");
            }
          } else if (cur_fld_no == FLD_SEND_GPS) {
            if (sync_mode == eSyncModeInitial || sync_mode == eSMSStop || sync_mode == eHttpStop || sync_mode == eExceptionHandled) {
              sync_mode = eGPSStart;
              strcpy(ui_data[FLD_SEND_GPS].bottomRow, "SENDING...     ");
            } else {
              pending_manual_gps = true;
              strcpy(ui_data[FLD_SEND_GPS].bottomRow, "PLEASE WAIT..  ");
            }
          } else if (cur_fld_no == FLD_HTTP_FAILS) {
            if (pcb_clear_state == 0) {
              pcb_clear_state = 1;
              strcpy(ui_data[FLD_HTTP_FAILS].bottomRow, "CLEAR BACKLOG? ");
            } else {
              // WIPE BACKLOG
              if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
                lcd.clear(); lcd.print("Wiping Backlog");
                SPIFFS.remove("/unsent.txt");
                SPIFFS.remove("/ftpunsent.txt");
                SPIFFS.remove("/unsent_pointer.txt");
                diag_http_present_fails = 0;
                diag_http_cum_fails = 0;
                pcb_clear_state = 0;
                vTaskDelay(2000 / portTICK_PERIOD_MS);
                lcd.clear(); lcd.print("BACKLOG CLEARED");
                vTaskDelay(1000 / portTICK_PERIOD_MS);
                xSemaphoreGive(i2cMutex);
              }
            }
          } else if (cur_fld_no == FLD_RF_CALIB) {
            if (calib_flag == 0) {
              calib_start_time = millis();
              calib_count.val = 0; calib_mode_flag.val = 1; calib_flag = 1;
              calib_header_drawn = 0;
              if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
                lcd.clear(); xSemaphoreGive(i2cMutex);
              }
            } else if (calib_flag == 1) {
              calib_flag = 2; // Stop
            }
          } else if (cur_fld_no == FLD_RF_RES) {
            if (rf_res_edit_state == 0) {
              rf_res_edit_state = 1; // Password entry mode
              strcpy(ui_data[FLD_RF_RES].topRow, "ENTER PASSWORD");
              strcpy(input_buf, "    ");
              cur_mode = eEditOn; cur_pos_no = 0; cur_char_no = 0;
            } else if (rf_res_edit_state == 1) {
              if (strcmp(input_buf, "2000") == 0) {
                rf_res_edit_state = 2; // Value entry mode
                strcpy(ui_data[FLD_RF_RES].topRow, "EDIT RF RES");
                snprintf(input_buf, 17, "%.2f", RF_RESOLUTION);
                cur_pos_no = 0; cur_char_no = 0;
              } else {
                rf_res_edit_state = 0;
                strcpy(ui_data[FLD_RF_RES].topRow, "RF RESOLUTION");
                cur_mode = eEditOff;
              }
            } else if (rf_res_edit_state == 2) {
              RF_RESOLUTION = atof(input_buf);
              File f = SPIFFS.open("/rf_res.txt", FILE_WRITE);
              if (f) { f.print(RF_RESOLUTION); f.close(); }
              // Requirement: Wipe all data and reboot after resolution change
              if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
                 lcd.clear(); lcd.print("RES CHANGED!");
                 vTaskDelay(1000/portTICK_PERIOD_MS);
                 lcd.clear(); lcd.print("WIPING DATA...");
                 SPIFFS.remove("/unsent.txt"); SPIFFS.remove("/ftpunsent.txt");
                 File root = SPIFFS.open("/"); 
                 File file = root.openNextFile();
                 while(file) {
                    String n = file.name();
                    if (!(n == "station.txt" || n == "rf_fw.txt" || n == "station.doc" || n == "rf_res.txt")) {
                      SPIFFS.remove(n.startsWith("/") ? n : "/" + n);
                    }
                    file.close(); file = root.openNextFile();
                 }
                 root.close();
                 lcd.clear(); lcd.print("DONE! REBOOTING");
                 vTaskDelay(2000 / portTICK_PERIOD_MS);
                 ESP.restart();
              }
            }
          } else if (cur_fld_no == FLD_DELETE_DATA) {
            if (delete_confirm_state == 0) {
              delete_confirm_state = 1;
              strcpy(ui_data[FLD_DELETE_DATA].topRow, "ARE YOU SURE?");
              strcpy(ui_data[FLD_DELETE_DATA].bottomRow, "PRESS SET: YES");
            } else {
              // Perform deletion
              if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
                 lcd.clear(); lcd.print("Deleting...");
                 SPIFFS.remove("/unsent.txt"); SPIFFS.remove("/ftpunsent.txt");
                 File root = SPIFFS.open("/"); 
                 File file = root.openNextFile();
                 while(file) {
                    String n = file.name();
                    if (!(n == "station.txt" || n == "rf_fw.txt" || n == "station.doc")) {
                      SPIFFS.remove(n.startsWith("/") ? n : "/" + n);
                    }
                    file.close(); file = root.openNextFile();
                 }
                 root.close();
                 lcd.clear(); lcd.print("DONE! REBOOTING");
                 vTaskDelay(2000 / portTICK_PERIOD_MS);
                 ESP.restart();
              }
            }
          } else if (cur_fld_no == FLD_SD_COPY) {
            if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
              lcd.clear(); lcd.print("COPYING TO SD...");
              copyFilesFromSPIFFSToSD("/"); 
              lcd.clear(); lcd.print("SD COPY DONE");
              vTaskDelay(2000 / portTICK_PERIOD_MS);
              xSemaphoreGive(i2cMutex);
              show_now = 1;
            }
          } else if (cur_fld_no == FLD_LOG) {
             if (cur_mode == eEditOff) {
                cur_mode = eEditOn;
                strcpy(input_buf, ui_data[FLD_LOG].bottomRow);
                cur_pos_no = 0; cur_char_no = 0;
             } else {
                if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
                   lcd.clear(); lcd.setCursor(0, 0); lcd.print("SEARCHING...");
                   xSemaphoreGive(i2cMutex);
                }

                char dt[17]; strcpy(dt, input_buf);
                int yr = atoi(String(dt).substring(0,4).c_str());
                int mo = atoi(String(dt).substring(4,6).c_str());
                int dy = atoi(String(dt).substring(6,8).c_str());
                int hr = atoi(String(dt).substring(9,11).c_str());
                int mn = atoi(String(dt).substring(12,14).c_str());
                int sNo = (hr * 4 + mn / 15 + 61) % 96;

                if (sNo <= 60) {
                   int daysInMonth[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
                   if ((yr%4==0 && yr%100!=0) || (yr%400==0)) daysInMonth[2]=29;
                   dy++; 
                   if (dy > daysInMonth[mo]) { dy=1; mo++; if(mo>12){mo=1; yr++;} }
                }

                char fn[50]; snprintf(fn, 50, "/%s_%04d%02d%02d.txt", station_name, yr, mo, dy);
                
                if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
                   lcd.clear();
                   
                   // Fallback check for legacy/normalized prefix mismatch (v5.56 standard)
                   if (!SPIFFS.exists(fn)) {
                      char fallback[50];
                      if (strlen(station_name) == 4 && isDigitStr(station_name)) {
                         snprintf(fallback, sizeof(fallback), "/00%s_%04d%02d%02d.txt", station_name, yr, mo, dy);
                      } else if (strlen(station_name) == 6 && strncmp(station_name, "00", 2) == 0) {
                         snprintf(fallback, sizeof(fallback), "/%s_%04d%02d%02d.txt", station_name + 2, yr, mo, dy);
                      } else {
                         strcpy(fallback, "");
                      }
                      if (strlen(fallback) > 0 && SPIFFS.exists(fallback)) {
                         strcpy(fn, fallback);
                      }
                   }

                   if (SPIFFS.exists(fn)) {
                      File f = SPIFFS.open(fn, FILE_READ);
                      bool found = false;
                      char line[128];
                      while(f.available()) {
                         String l = f.readStringUntil('\n');
                         if (l.substring(0,2).toInt() == sNo) { strcpy(line, l.c_str()); found = true; break; }
                      }
                      f.close();

                      if (found) {
                         float tf=0, hf=0, af=0, rf=0; int wf=0;
                         if (SYSTEM == 0) {
                            float irf, crf; sscanf(line, "%*d,%*[^,],%*[^,],%f,%f", &irf, &crf);
                            lcd.setCursor(0,0); lcd.print("CUM_RF:"); lcd.setCursor(0,1); lcd.print(crf,2);
                         } else if (SYSTEM == 1) {
                            sscanf(line, "%*d,%*[^,],%*[^,],%f,%f,%f,%d", &tf, &hf, &af, &wf);
                            lcd.setCursor(0,0); char b1[17]; snprintf(b1,17,"T:%-4.1f H:%-4.1f",tf,hf); lcd.print(b1);
                            lcd.setCursor(0,1); char b2[17]; snprintf(b2,17,"AWS:%-4.1f WD:%-d",af,wf); lcd.print(b2);
                         } else if (SYSTEM == 2) {
                            sscanf(line, "%*d,%*[^,],%*[^,],%f,%f,%f,%f,%d", &rf, &tf, &hf, &af, &wf);
                            lcd.setCursor(0,0); char b1[17]; snprintf(b1,17,"R:%-3.1f T:%-4.1f",rf,tf); lcd.print(b1);
                            lcd.setCursor(0,1); char b2[17]; snprintf(b2,17,"H:%-2.0f AWS:%-4.1f",hf,af); lcd.print(b2);
                         }
                         xSemaphoreGive(i2cMutex);
                         vTaskDelay(5000 / portTICK_PERIOD_MS);
                      } else { lcd.print("NOT IN FILE"); xSemaphoreGive(i2cMutex); vTaskDelay(2000/portTICK_PERIOD_MS); }
                   } else { lcd.print("FILE NOT FOUND"); xSemaphoreGive(i2cMutex); vTaskDelay(2000/portTICK_PERIOD_MS); }
                }
                cur_mode = eEditOff;
             }
          } else {
             // Generic Edit
             if (cur_mode == eEditOff) {
                if (ui_data[cur_fld_no].fieldType != eDisplayOnly && ui_data[cur_fld_no].fieldType != eLive) {
                   cur_mode = eEditOn;
                   strcpy(input_buf, ui_data[cur_fld_no].bottomRow);
                   cur_pos_no = 0; cur_char_no = 0;
                }
             } else {
                if (cur_fld_no == FLD_STATION) {
                   String trimmed = String(input_buf);
                   trimmed.trim();
                   // Requirement (v5.56): if it's numeric "00XXXX", treat as "XXXX"
                   if (trimmed.length() == 6 && isDigitStr(trimmed.c_str()) && trimmed.startsWith("00")) {
                      trimmed = trimmed.substring(2);
                   }
                   strncpy(station_name, trimmed.c_str(), 15);
                   station_name[15] = '\0';
                   strcpy(ftp_station, station_name); // Sync for GPRS/FTP task

                   // v5.60: Save to NVS, station.txt AND station.doc to prevent revert
                   Preferences prefs; prefs.begin("sys-config", false); 
                   prefs.putString("station", station_name); prefs.end();
                   File f1 = SPIFFS.open("/station.txt", FILE_WRITE);
                   if (f1) { f1.print(station_name); f1.close(); }
                   File f2 = SPIFFS.open("/station.doc", FILE_WRITE);
                   if (f2) { f2.print(station_name); f2.close(); }
                   // Requirement: Acquire GPS whenever ID changes (eStartupGPS does GPS + Health)
                   if (sync_mode == eSyncModeInitial || sync_mode == eSMSStop || 
                       sync_mode == eHttpStop || sync_mode == eExceptionHandled) {
                      sync_mode = eStartupGPS;
                      strcpy(ui_data[FLD_SEND_GPS].bottomRow, "ACQUIRING GPS..");
                   } else {
                      pending_manual_gps = true;
                   }
                } else if (cur_fld_no == FLD_DATE) {
                   int dd, mm, yy;
                   if (sscanf(input_buf, "%02d-%02d-%04d", &dd, &mm, &yy) == 3) {
                      current_day = dd; current_month = mm; current_year = yy;
                      if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(I2C_MUTEX_WAIT_TIME)) == pdTRUE) {
                         rtc.adjust(DateTime(current_year, current_month, current_day, current_hour, current_min, 0));
                         xSemaphoreGive(i2cMutex);
                      }
                   }
                } else if (cur_fld_no == FLD_TIME) {
                   int hh, mi;
                   if (sscanf(input_buf, "%02d:%02d", &hh, &mi) == 2) {
                      current_hour = hh; current_min = mi;
                      if (xSemaphoreTake(i2cMutex, pdMS_TO_TICKS(I2C_MUTEX_WAIT_TIME)) == pdTRUE) {
                         rtc.adjust(DateTime(current_year, current_month, current_day, current_hour, current_min, 0));
                         record_hr = current_hour;
                         record_min = (current_min / 15) * 15;
                         File fileTemp4 = SPIFFS.open("/signature.txt", FILE_WRITE);
                         if (fileTemp4) {
                            snprintf(signature, 17, "%04d-%02d-%02d,%02d:%02d", current_year, current_month, current_day, record_hr, record_min);
                            fileTemp4.print(signature);
                            fileTemp4.close();
                         }
                         rtcTimeChanged = true;
                         xSemaphoreGive(i2cMutex);
                      }
                   }
                }
                strcpy(ui_data[cur_fld_no].bottomRow, input_buf);
                cur_mode = eEditOff;
             }
          }
          show_now = 1;
          break;

        case 4: // LEFT
          if (cur_mode == eEditOn && cur_pos_no > 0) cur_pos_no--;
          show_now = 1;
          break;

        case 5: // DOWN
          if (cur_mode == eEditOn) {
            cur_char_no = (cur_char_no - 1 + len) % len;
            if (cur_pos_no < 16) input_buf[cur_pos_no] = inpCharSet[ui_data[cur_fld_no].fieldType][cur_char_no];
          } else {
            int start_fld = cur_fld_no;
            do {
              cur_fld_no = (cur_fld_no + FLD_COUNT - 1) % FLD_COUNT;
            } while (!isFieldVisible(cur_fld_no) && cur_fld_no != start_fld);

            if (cur_fld_no == FLD_LOG && last_recorded_yy > 0) {
               snprintf(ui_data[FLD_LOG].bottomRow, 17, "%04d%02d%02d %02d:%02d", 
                        last_recorded_yy, last_recorded_mm, last_recorded_dd, 
                        last_recorded_hr, last_recorded_min);
            } else if (cur_fld_no == FLD_LOG) {
               int p_min = (current_min / 15) * 15;
               snprintf(ui_data[FLD_LOG].bottomRow, 17, "%04d%02d%02d %02d:%02d", 
                        current_year, current_month, current_day, current_hour, p_min);
            }
          }
          show_now = 1;
          break;

        case 6: // RIGHT
          if (cur_mode == eEditOn && cur_pos_no < 15) cur_pos_no++;
          show_now = 1;
          break;
        }
      }
    }
    if (lcdkeypad_start && lcd_timer) {
      // v5.60: Stay awake during active manual triggers or startup tasks
      if (sync_mode == eSMSStart || sync_mode == eGPSStart || 
          sync_mode == eStartupGPS || cur_fld_no == FLD_LOG && cur_mode == eEditOn) {
        timerWrite(lcd_timer, 0);
      }
    }
    esp_task_wdt_reset();
    vTaskDelay((lcdkeypad_start ? 10 : 50) / portTICK_PERIOD_MS);
  }
}
